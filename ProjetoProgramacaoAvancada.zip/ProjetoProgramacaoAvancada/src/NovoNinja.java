
public class NovoNinja extends NinjaEscondido {

	public String nome;
	public String modelo;
	
	public NovoNinja (String nome) {
	
	this.nome = nome;
	System.out.println("Chamando refor�os do novo ninja " + this.nome + " \n");
	}
}
