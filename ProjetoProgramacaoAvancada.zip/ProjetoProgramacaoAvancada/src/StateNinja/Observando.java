package StateNinja;

public class Observando implements StateNinjaEmAcao {

	@Override
	public StateNinjaEmAcao Observando() {
		System.out.println("Os ninjas se escondem e ficam observando o movimento do fugitivo;");
		return new Observando();
	}

	@Override
	public StateNinjaEmAcao Atacando() {
		System.out.println("Os ninjas continuam avan�ado e utilizando ataques a longa dist�ncia;");
		return new Atacando();
	}

	@Override
	public StateNinjaEmAcao Recuando() {
		System.out.println("Os ninjas que est�o com problemas se afastam;");
		return new Recuando();
	}

	@Override
	public StateNinjaEmAcao Reagrupando() {
		System.out.println("Todos os ninjas em seus respectivos grupos voltam para suas forma��es");
		return new Reagrupando();
	}

}
