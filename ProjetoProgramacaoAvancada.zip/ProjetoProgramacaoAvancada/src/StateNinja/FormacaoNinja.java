package StateNinja;

// Esta classe � utilizada como base para NinjaEmMovimento
public class FormacaoNinja {
	
	protected StateNinjaEmAcao estado;
	
	public void Observando() {
		estado = new Observando();
	}
	public void Atacando() {
		estado = new Atacando();
	}
	public void Recuando() {
		estado = new Recuando();
	}
	public void Reagrupando() {
		estado = new Reagrupando();
	}
}
