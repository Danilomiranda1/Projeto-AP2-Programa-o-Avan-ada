package StateNinja;

public class Reagrupando implements StateNinjaEmAcao{
	
	@Override
	public StateNinjaEmAcao Observando() {
		System.out.println("Os ninjas observam escondidos de longe;");
		return new Observando();
	}

	@Override
	public StateNinjaEmAcao Atacando() {
		System.out.println("Os ninjas continuam avan�ado e utilizando ataques a longa dist�ncia;");
		return new Atacando();
	}

	@Override
	public StateNinjaEmAcao Recuando() {
		System.out.println("Os ninjas que est�o com problemas se afastam;");
		return new Recuando();
	}

	@Override
	public StateNinjaEmAcao Reagrupando() {
		System.out.println("Todos os ninjas que est�o neste momento se preparam para um ataque em conjunto;");
		return new Reagrupando();
	}

}
