package StateNinja;

public class Recuando implements StateNinjaEmAcao {
	
	@Override
	public StateNinjaEmAcao Observando() {
		System.out.println("Os ninjas observam escondidos de longe;");
		return new Observando();
	}

	@Override
	public StateNinjaEmAcao Atacando() {
		System.out.println("Os ninjas continuam avan�ado e utilizando ataques a longa dist�ncia;");
		return new Atacando();
	}

	@Override
	public StateNinjaEmAcao Recuando() {
		System.out.println("Os ninjas encontram perigo demais, e todos eles voltam para se preparar;");
		return new Recuando();
	}

	@Override
	public StateNinjaEmAcao Reagrupando() {
		System.out.println("Todos os ninjas em seus respectivos grupos voltam para suas forma��es");
		return new Reagrupando();
	}

}
