package StateNinja;

public interface StateNinjaEmAcao {
	
	StateNinjaEmAcao Observando();
	StateNinjaEmAcao Atacando();
	StateNinjaEmAcao Recuando();
	StateNinjaEmAcao Reagrupando();
}
