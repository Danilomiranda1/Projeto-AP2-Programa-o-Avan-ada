package PHT;

public abstract class NinjaPerseguidor {

protected String ninjaemmovimento;
public abstract String liberarNinja();
public abstract NinjaPerseguidor clonar();
		
	public String getNinjaEmMovimento() {
			return ninjaemmovimento;
		}
	public void setNinjaEmMovimento(String ninjaemmovimento) {
			this.ninjaemmovimento = ninjaemmovimento;
	}
}
