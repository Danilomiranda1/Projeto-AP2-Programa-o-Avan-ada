public class FactoryNinja {

	
	public NinjaEscondido getFactoryNinja (String nome, String modelo) {
		if(nome.equals("ninja"))
			return new NovoNinja (nome);
		
		if(nome.equals("fugitivo"))
			
		return null;
		return null;

	}
	
}
