import java.util.Observable;
	public class NinjaEmMissao extends Observable implements Ninja{

		private String botao = "" ; 
		public void cima() {
			botao = "cima";
			System.out.println("O ninja pula e continua avan�ando;");
			this.mudaEstado();
		}
		public void direita() {
			botao = "direita";
			System.out.println("O ninja se move para a direita e continua avan�ando;");
		this.mudaEstado();
		}
		public void esquerda() {
			botao = "esquerda";
			System.out.println("O ninja se move para a esquerda e continua avan�ando;");
			this.mudaEstado();
		}
		public void baixo() {
			botao = "baixo";
		System.out.println("O ninja se abaixa e prepara seu pr�ximo movimento;");
		this.mudaEstado();
		}

		public void investida() {
			botao = "investida";
		System.out.println("O ninja usa sua espada para dar uma investida ofensiva;");
		this.mudaEstado();
		}
		
		public void mudaEstado() {
			setChanged(); 
			notifyObservers(botao);
		}
		
		public String nome;
		public String modelo;
		public NinjaEmMissao (String nome) {
		
		this.nome = nome;
		System.out.println("O  " + this.nome + " foi identificado \n");
}
		@Override
		public void jutso() {
			
		}
		@Override
		public void esquivar() {
			
		}
}
