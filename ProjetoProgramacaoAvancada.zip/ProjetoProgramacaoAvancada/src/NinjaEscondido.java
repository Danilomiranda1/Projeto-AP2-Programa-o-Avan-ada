public abstract class NinjaEscondido {
	
public interface Ninja{
		
		 public void cima();
		 public void direita();
		 public void esquerda();	
		 public void baixo();
		 public void investida();
	}
}
