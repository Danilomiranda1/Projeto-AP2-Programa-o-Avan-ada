public class Fugitivo {
	
	public String nome;
	public String modelo;
	public Fugitivo (String nome) {
	
	this.nome = nome;
	System.out.println("Aten��o todos " + this.nome + " acabou de ser visto; \n");
	}
}
