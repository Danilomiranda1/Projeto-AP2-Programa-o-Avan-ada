import java.util.Observable;
import java.util.Observer;
import PHT.NinjaPerseguidor;

public class NinjaEmMovimento extends NinjaPerseguidor implements Observer, Ninja {

	@Override
	public void cima() {
		System.out.println("O ninja pula em persegui��o ao Fugitivo;");	
	}
	@Override
	public void direita() {
		System.out.println("O fugitivo dobra pela direita e o ninja segue em perseguicao;");	
	}
	@Override
	public void esquerda() {
		System.out.println("O fugitivo dobra pela esquerda e o ninja segue em perseguicao;");	
	}
	@Override
	public void baixo() {
		System.out.println("O ninja se abaixa rapidamente para esquivar de impencilhos em sua frente;");	
	}
	@Override
	public void investida() {
		System.out.println("O ninja parte em disparada para se aproximar do Fugitivo;");	
	}
	@Override
	public void jutso() {
		System.out.println("O ninja utiliza seus poderes para parar o Fugitivo;");	
	}
	@Override
	public void esquivar() {
		System.out.println("O ninja se esquiva do Jutso do Fugitivo;");	
	}
	@Override
	public void update(Observable arg0, Object arg1) {
	}
	
	public String nome;
	public String modelo;
	
	public NinjaEmMovimento (String nome) {

		this.nome = nome;
		System.out.println("Chamando o " + this.nome + " um novo ninja a perseguicao; \n");
	}
	
	protected NinjaEmMovimento( NinjaEmMovimento ninjaemmovimentoPrototype) {
		this.ninjaemmovimento = ninjaemmovimentoPrototype.getNinjaEmMovimento();
	}
	public NinjaEmMovimento() {
	ninjaemmovimento = " ";	
	}
	
	@Override
	public String liberarNinja() {
		System.out.println("");
		return "Outro ninja est� indo para ajudar; " + ninjaemmovimento +getNinjaEmMovimento();

	}
	@Override
	public NinjaPerseguidor clonar() {
		return new NinjaEmMovimento(this);
	}
	public void addObserver(Fugitivo fugitivoA) {
		// TODO Auto-generated method stub
		
	}
}
