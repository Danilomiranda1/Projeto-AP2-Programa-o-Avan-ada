import PHT.NinjaPerseguidor;
import StateNinja.Atacando;
import StateNinja.FormacaoNinja;
import StateNinja.Observando;
import StateNinja.Reagrupando;
import StateNinja.Recuando;

public class Missao {
	public static void main(String[] args) {
		System.out.println("|     MISS�O DE BUSCA DOS NINJAS!   |");
		System.out.println("\n");

	    Atacando at = new Atacando();
	    Observando ob = new Observando();
	    Reagrupando re = new Reagrupando();
	    Recuando rc = new Recuando();
	    		
		System.out.println("|   PRIMEIRO EXEMPLO: FACTORY ONLY  |");  // M�todo utilizado para mudar o estado dos ninja em execu��o
		System.out.println("\n");
			
		FactoryNinja fac = new FactoryNinja();
		String nome = "ninja";
		if(nome == "ninja") {
			System.out.println("O ninja confirma sua presen�a na miss�o;\n");
		}
		String modelo = "ninja";	
		fac.getFactoryNinja (nome,modelo);
		
		//Observador
		NinjaEmMovimento ninjaA = new NinjaEmMovimento("novo ninja.");
		//Observado
		Fugitivo fugitivoA = new Fugitivo("o fugitivo");
		
		NinjaEmMovimento no = new NinjaEmMovimento();
		//Utilizando como base para cria��o de diversos clones / prot�tipos;
		

		System.out.println("|   SEGUNDO EXEMPLO: OBSERVER ONLY  |");
		System.out.println("\n");

			
				System.out.println("\n\n");
				ninjaA.addObserver(fugitivoA);
				ninjaA.esquerda();
				ninjaA.direita();
				ninjaA.esquivar();
				ninjaA.jutso();
				ninjaA.cima();
				
		System.out.println("\n");
		System.out.println("|   TERCEIRO EXEMPLO: STATE ONLY    |");
		System.out.println("\n");
		
		re.Reagrupando();
		ob.Observando();
		at.Atacando();
		rc.Recuando();
				
		System.out.println("|   QUARTO EXEMPLO: PROTOTYPE ONLY  |");
		System.out.println("\n");
	
		no.setNinjaEmMovimento("O ninja bate na parede e fica atordoado;");
		NinjaPerseguidor a1 =  no.clonar();
		a1.setNinjaEmMovimento("Todos os ninjas devem seguir a perseguicao;");
		a1.setNinjaEmMovimento("Um novo ninja ja foi liberado para ajudar na perseguicao;");
		System.out.println(no.liberarNinja());
		System.out.println(a1.liberarNinja());
		
// Todos os objetos trabalham entre si, e quando h� uma mudan�a todos se alteram tamb�m, ambos s�o notificados;		
	}
}
